(function ($) {
    "use strict";
    jQuery(document).ready(function() {

        // Activate SlickNav
        $('.main-menu').slicknav({
            // prependTo: '.mobile-menu',
            label: '',
            brand: '<img class="logo" src="../assets/images/logo.png">'
        });

    });
})(jQuery);