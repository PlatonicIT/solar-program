<?php /* C:\xampp\htdocs\solar\resources\views/public/footer/footer.blade.php */ ?>

	<!-- Footer -->
	<footer class="footer-wrap">
		<div class="container">
			<div class="row align-items-center text-center justify-content-center">
				<div class="col-lg-6">
					<p class="copyright">&copy; <span id="date">
                        <?php if((isset(\App\Models\Setting::first()->copyright))): ?>
					<?php echo e(App\Models\Setting::first()->copyright, false); ?>

					<?php else: ?>
					Copyright <?php echo e(\Carbon\Carbon::now()->year, false); ?> Solar Program All Rights Reserved
					<?php endif; ?>
						</span>
					</p>
				</div>

				<div class="col-lg-6 text-right">
					<ul class="footer-menu">
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Terms and Conditions</a></li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
	<!-- End of Footer -->