<?php /* C:\xampp\htdocs\solar\resources\views/public/home.blade.php */ ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('css'); ?>
  <style>
  .home_heading {color:#ffffff!important}
  .home_heading h1{color:#ffffff !important}
  <?php if((isset(\App\Models\Setting::first()->background))): ?>
    .banner-wrap{background-image: url(<?php echo e(asset('storage')."/".\App\Models\Setting::first()->background, false); ?>)}
    <?php else: ?>
   .banner-wrap{background-image: url(<?php echo e(asset('assets/images/default/banner-bg.jpg'), false); ?>)}
    <?php endif; ?>
   
  </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('title',"Home - Solar Program"); ?>
<?php $__env->startSection('content'); ?>
    <!-- Banner -->
    <section class="banner-wrap" style="">
        <div class="container">
            <div class="row justify-content-center align-items-center text-center">
                <div class="col-lg-8">
                <?php if((isset(\App\Models\Setting::first()->heading))): ?>
                    <div class="home_heading">
                     <?php echo \App\Models\Setting::first()->heading; ?>

                    </div>
                <?php else: ?>
                    <h3>Compare quotes from up to four local home service companies.</h3>
                <?php endif; ?>    
                    <div class="quote-box">
                        <p>Start your project today!</p>
                        <?php if(Session::get('success')): ?>
                          <p class="text-success" id="notice"><?php echo e(Session::get('success'), false); ?></p>
                        <?php endif; ?>
                        <p class="text-danger" v-if="this.error">{{ this.error.zipcode }} </p>
                        <input @keyup="surVey" id="zipcode"  name="zipcode" v-model="zipcode" type="text" placeholder="Enter your zip code">
                        <button  type="button" class="button" data-toggle="modal" v-if="validate && zipvalid" data-target="#exampleModal">Get Quotes</button>
                        <button @click="surVey" type="button" class="button"  v-else >Get Quotes</button>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End of Banner -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>