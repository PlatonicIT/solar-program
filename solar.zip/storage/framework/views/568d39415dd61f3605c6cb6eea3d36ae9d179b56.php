<?php /* C:\xampp\htdocs\solar\vendor\encore\laravel-admin\src/../resources/views/form/hidden.blade.php */ ?>
<input type="hidden" name="<?php echo e($name, false); ?>" value="<?php echo e($value, false); ?>" class="<?php echo e($class, false); ?>" <?php echo $attributes; ?> />
