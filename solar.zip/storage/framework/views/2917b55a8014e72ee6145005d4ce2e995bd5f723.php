<?php /* C:\xampp\htdocs\solar\resources\views/admin/answer.blade.php */ ?>
<h1 style="text-align: center">ZipCode <i class="fa fa-angle-double-right"></i> <?php echo e($survey->zipcode, false); ?></h1>
<div class="container faq_section">
    <?php $__currentLoopData = $survey->survey; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="FaQ_Each">
        <section class="box">
		  	<span>
		  		<i class="fa fa-plus" aria-hidden="true"></i>
		  		<i class="fa fa-minus" id="other" aria-hidden="true"></i>
		  	</span>
            &nbsp;&nbsp;<span><?php echo e($key, false); ?></span>
        </section>
        <section class="draw">
            <?php if(isset($answer['radio'])): ?>
                <h3 ><?php echo e($answer['radio'], false); ?></h3>
            <?php endif; ?>
            <?php if(isset($answer['text'])): ?>
                <?php $__currentLoopData = $answer['text']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemkey=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h3><?php echo e($itemkey, false); ?> <i class="fa fa-angle-double-right"></i> <?php echo e($item, false); ?></h3>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </section>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<script>
    $(document).ready(function(){
        $(".box").click(function(){
            $(this).next().slideToggle("fast");
            $(this).find('i').toggle();
        });
    });
</script>