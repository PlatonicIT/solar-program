<?php /* C:\xampp\htdocs\solar\resources\views/public/master.blade.php */ ?>
<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">
    <meta name="author" content="csesumonpro">

	<!-- Site Title -->
	<title><?php echo $__env->yieldContent('title','Home - Solar Program'); ?></title>

	<!-- Favicon Icon -->
	<?php if((isset(\App\Models\Setting::first()->favicon))): ?>
	<link href="<?php echo e(asset('storage')."/".\App\Models\Setting::first()->favicon, false); ?>" rel="shortcut icon" type="image/png">
	<?php else: ?>
	<link href="<?php echo e(asset('assets/images/default/favicon.png'), false); ?>" rel="shortcut icon" type="image/png">
	<?php endif; ?>
	
	
	<!-- Google Fonts -->
	<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:300i,400,400i,500,700,900">
	<!-- Vendor CSS -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendor.min.css'), false); ?>">

	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/css/nice-select.min.css">

	<!-- Style CSS -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms.css'), false); ?>">	
	<!-- Style CSS -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css'), false); ?>">	
	<!-- Responsive CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/responsive.css'), false); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/developer.css'), false); ?>">
    <style>
        #progressbar li {
            width: calc(100%/<?php echo e(\App\Models\Question::all()->count(), false); ?>);
		}
		.invalid{pointer-events: none}
		[v-cloak] {
			display: none;
		  }
    </style>
    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body>
<div id="app" v-cloak>
<?php echo $__env->make('public.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content',''); ?>

<?php echo $__env->make('public.footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- Modal -->
	<div  class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-lg-custom" role="document">
			<div class="modal-content">
			<div class="modal-header align-items-center">
				<!-- progressbar -->
				<ul id="progressbar">
					<?php if(\App\Models\Question::all()->count()): ?>
						<?php $__currentLoopData = \App\Models\Question::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="
							<?php if($loop->index==0): ?>
								active
							<?php endif; ?>">
                            <?php echo e($question->question, false); ?>

						</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

				</ul>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<!-- Multi step form -->
				<section class="multi_step_form">
					<form id="msform" action="<?php echo e(route('survey'), false); ?>" method="POST">
                        <?php echo csrf_field(); ?>
						<!-- fieldsets -->
						<?php if(\App\Models\Question::all()->count()): ?>
							<?php $__currentLoopData = \App\Models\Question::latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<fieldset>
							<h3><?php echo e($question->question, false); ?></h3>
								<input type="hidden" name="zipcode" v-model="zipcode">
								
							<ul class="bills">
								<?php $__currentLoopData = $question->question_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								
								<?php
									if($option->option_type=='1'){
										$type = 'radio';
									}elseif($option->option_type=='2'){
										$type = 'text';
									}
								?>
								<li class="radio">
									<label>
										<input  
										@change="optionValid(<?php echo e($question->id, false); ?>,<?php echo e($option->id, false); ?>)"
										@keyup="optionValid(<?php echo e($question->id, false); ?>,<?php echo e($option->id, false); ?>)"

										placeholder="<?php echo e($option->question_option, false); ?>"

										type="<?php echo e($type, false); ?>" <?php if($type=='text'): ?>  
										v-model="text['<?php echo e($option->id, false); ?>']"
										name="answer[<?php echo e($question->question, false); ?>][<?php echo e($type, false); ?>][<?php echo e($option->question_option, false); ?>]" 
										<?php else: ?> v-model="option['<?php echo e($question->id, false); ?>']" name="answer[<?php echo e($question->question, false); ?>][<?php echo e($type, false); ?>]" <?php endif; ?>
										<?php if($type=='radio'): ?>  value="<?php echo e($option->question_option, false); ?>" <?php endif; ?> >
										<?php if($type=='radio'): ?> <?php echo e($option->question_option, false); ?> <?php endif; ?>
									</label>
								</li>
								
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>

							<?php if($loop->index==0): ?>
                            <a class="action-button " href="<?php echo e(url('/'), false); ?>">back</a>
							<?php else: ?>
							<button @click.prevent="trueIsActive"  type="button"  class="action-button previous previous_button">Back</button>
							<?php endif; ?>
                            <?php if($loop->last): ?>
                                <button type="submit" class="action-button">Finish</button>
							<?php else: ?>
                                <button @click.prevent="flaseIsActive" type="button" :class="!isActive ? 'invalid' : 'valid' "  class="next action-button">Continue</button>
                            <?php endif; ?>
						</fieldset>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>

					</form>
				</section>
				<!-- End Multi step form -->
				
			</div>
			</div>
		</div>
	</div>
	
</div>
  

	<!-- Vendor JS -->
	<script type="text/javascript" src="<?php echo e(asset('js/solar.js'), false); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('assets/js/vendor.min.js'), false); ?>"></script>
	<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/js/jquery.nice-select.min.js"></script>
	<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

	<!-- Forms Scripts -->
	<script type="text/javascript" src="<?php echo e(asset('assets/js/form.js'), false); ?>"></script>
	<!-- Custom Scripts -->
    <script type="text/javascript" src="<?php echo e(asset('assets/js/scripts.js'), false); ?>"></script>
    <!-- Code injected by live-server -->
    <script type="text/javascript" src="<?php echo e(asset('assets/js/svgsupport.js'), false); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/developerjs.js'), false); ?>"></script>
    <?php echo $__env->yieldPushContent('js'); ?>

</body>
</html>